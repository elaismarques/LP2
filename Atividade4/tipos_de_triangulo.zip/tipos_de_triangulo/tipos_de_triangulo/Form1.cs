﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tipos_de_triangulo
{
    public partial class Form1 : Form
    {
        double primeiro_valor, segundo_valor, terceiro_valor;

        private void txtValorUm_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorUm.Text, out primeiro_valor))
            {
                MessageBox.Show("Insira um valor númerico!");
                txtValorUm.Text = "";
            }
            if (primeiro_valor <= 0)
            {
                MessageBox.Show("O valor deve ser maior que zero!");
               
            }
        }

        private void txtValorDois_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorDois.Text, out segundo_valor))
            {
                MessageBox.Show("Insira um valor númerico!");
                txtValorDois.Text = "";
            }
            else if ( segundo_valor <= 0)
            {
                MessageBox.Show("O valor deve ser maior do que zero!");
                txtValorDois.Text = "";
            }

        }

        private void txtValorTres_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtValorTres.Text, out terceiro_valor) || (terceiro_valor <= 0))
            {
                MessageBox.Show("Insira um valor númerico maior do que zero!");
                txtValorTres.Text = "";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorUm.Text = "";
            txtValorDois.Text = "";
            txtValorTres.Text = "";
            ;
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (primeiro_valor <(segundo_valor + terceiro_valor)&&
                    (primeiro_valor > Math.Abs(segundo_valor - terceiro_valor)) &&
                    (segundo_valor < (primeiro_valor + terceiro_valor)) &&
                    (segundo_valor > Math.Abs(primeiro_valor - terceiro_valor)) &&
                    (terceiro_valor < (primeiro_valor + segundo_valor)) &&
                    (terceiro_valor > Math.Abs(primeiro_valor - segundo_valor)))
            {
                MessageBox.Show("Não é Triangulo!");
            }

                else if (primeiro_valor == segundo_valor && (segundo_valor == terceiro_valor) && (terceiro_valor == primeiro_valor))
                {
                    MessageBox.Show("É equilatero");
                }
                else if (primeiro_valor != segundo_valor && (segundo_valor != terceiro_valor) && (terceiro_valor != primeiro_valor))
                {
                    MessageBox.Show("É Escaleno");
                }
                else
                {
                    MessageBox.Show("É Isosceles");
                }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
