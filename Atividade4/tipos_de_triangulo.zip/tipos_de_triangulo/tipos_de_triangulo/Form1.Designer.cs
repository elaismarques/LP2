﻿namespace tipos_de_triangulo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblValorUm = new System.Windows.Forms.Label();
            this.lblValorDois = new System.Windows.Forms.Label();
            this.lblValorTres = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.txtValorUm = new System.Windows.Forms.TextBox();
            this.txtValorDois = new System.Windows.Forms.TextBox();
            this.txtValorTres = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblValorUm
            // 
            this.lblValorUm.AutoSize = true;
            this.lblValorUm.Location = new System.Drawing.Point(35, 34);
            this.lblValorUm.Name = "lblValorUm";
            this.lblValorUm.Size = new System.Drawing.Size(40, 13);
            this.lblValorUm.TabIndex = 0;
            this.lblValorUm.Text = "Valor 1";
            // 
            // lblValorDois
            // 
            this.lblValorDois.AutoSize = true;
            this.lblValorDois.Location = new System.Drawing.Point(35, 84);
            this.lblValorDois.Name = "lblValorDois";
            this.lblValorDois.Size = new System.Drawing.Size(40, 13);
            this.lblValorDois.TabIndex = 1;
            this.lblValorDois.Text = "Valor 2";
            // 
            // lblValorTres
            // 
            this.lblValorTres.AutoSize = true;
            this.lblValorTres.Location = new System.Drawing.Point(35, 131);
            this.lblValorTres.Name = "lblValorTres";
            this.lblValorTres.Size = new System.Drawing.Size(40, 13);
            this.lblValorTres.TabIndex = 2;
            this.lblValorTres.Text = "Valor 3";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(38, 207);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 3;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // txtValorUm
            // 
            this.txtValorUm.Location = new System.Drawing.Point(126, 27);
            this.txtValorUm.Name = "txtValorUm";
            this.txtValorUm.Size = new System.Drawing.Size(100, 20);
            this.txtValorUm.TabIndex = 4;
            this.txtValorUm.TextChanged += new System.EventHandler(this.txtValorUm_TextChanged);
            // 
            // txtValorDois
            // 
            this.txtValorDois.Location = new System.Drawing.Point(126, 77);
            this.txtValorDois.Name = "txtValorDois";
            this.txtValorDois.Size = new System.Drawing.Size(100, 20);
            this.txtValorDois.TabIndex = 5;
            this.txtValorDois.TextChanged += new System.EventHandler(this.txtValorDois_TextChanged);
            // 
            // txtValorTres
            // 
            this.txtValorTres.Location = new System.Drawing.Point(126, 124);
            this.txtValorTres.Name = "txtValorTres";
            this.txtValorTres.Size = new System.Drawing.Size(100, 20);
            this.txtValorTres.TabIndex = 6;
            this.txtValorTres.TextChanged += new System.EventHandler(this.txtValorTres_TextChanged);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(151, 207);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtValorTres);
            this.Controls.Add(this.txtValorDois);
            this.Controls.Add(this.txtValorUm);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.lblValorTres);
            this.Controls.Add(this.lblValorDois);
            this.Controls.Add(this.lblValorUm);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblValorUm;
        private System.Windows.Forms.Label lblValorDois;
        private System.Windows.Forms.Label lblValorTres;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.TextBox txtValorUm;
        private System.Windows.Forms.TextBox txtValorDois;
        private System.Windows.Forms.TextBox txtValorTres;
        private System.Windows.Forms.Button btnLimpar;
    }
}

